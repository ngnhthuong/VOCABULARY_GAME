const mongoose = require("mongoose");

// const roomSchema = new mongoose.Schema(
//   {
   
//   },
//   {
//     timestamps: true,
//   }
// );

module.exports = mongoose.model("room", roomSchema);