// import AuthLogin from '../components/authen/AuthLogin.js'
import AuthSign from "../components/authen/AuthSign"
export default function Login(){
    return <AuthSign/>
}