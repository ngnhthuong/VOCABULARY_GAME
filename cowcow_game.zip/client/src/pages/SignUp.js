import AuthSignUp from '../components/authen/AuthSignUp.js';
export default function SignUp(){
    return <AuthSignUp/>
}