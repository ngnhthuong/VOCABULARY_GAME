import CreateUser from "../components/authen/CreateUser";
export default function IdentifyUser() {
    return <>
        <CreateUser/>
    </>
}